from flask import Flask, render_template, url_for, request, redirect
from flask_sqlalchemy import SQLAlchemy
import sqlite3 as sql
import os
import sys
import requests

con = sql.connect('alldata.db')
cur = con.cursor()


app = Flask(__name__)


email = ''
psw = ''
location = ''

@app.route('/')
@app.route('/home_f')
def home_f():
    return render_template('index_f.html')

@app.route('/change_loc', methods=['GET', 'POST'])
def profile():
    global email
    if request.method == 'POST':
        with sql.connect("alldata.db") as con:
            cur = con.cursor() 
            cur.execute("""UPDATE users SET location = '%s' WHERE email = '%s'""" % (str(request.form['location']), email))
            return redirect(url_for('home'))
    return render_template('profile.html')

@app.route('/offers')
def offers():
    with sql.connect("alldata.db") as con:
        cur = con.cursor() 
        result = cur.execute("""SELECT email, location from users""").fetchall()
        string = ''
        for i in result:
            txt = ' '.join(i)
            string = string + '<br>' + txt
        return string

@app.route('/offers_f')
def offers_f():
    return render_template('offers_f.html')

@app.route('/home')
def home():
    return render_template('index.html')


@app.route('/help_f')
def help_f():
    return render_template('help_f.html')

@app.route('/help')
def help():
    return render_template('help.html')

@app.route('/about')
def about():
    return render_template('about.html')


@app.route('/about_f')
def about_f():
    return render_template('about_f.html')



@app.route('/login_b', methods=['GET', 'POST'])
def login_b():
    with sql.connect("alldata.db") as con:
        cur = con.cursor() 
        result = cur.execute("""SELECT email, password FROM users""").fetchall()
        emails = []
        passwords = []
        for i in result:
            emails.append(str(i[0]))
        for i in result:
            passwords.append(str(i[1]))
        if request.method == 'POST':
            print(emails, passwords, request.form['psw'], request.form['email'])
            if str(request.form['psw']) in passwords and str(request.form['email']) in emails:
                
                if str(request.form['psw']) == passwords[emails.index(str(request.form['email']))]:
                    global email
                    email = str(request.form['email'])
                    psw = str(request.form['psw'])
                    return redirect(url_for('home'))
                else:
                    return redirect(url_for('login_b'))
            else:
                return redirect(url_for('login_b'))
        return render_template('login_b.html')
    
@app.route('/login_g', methods=['GET', 'POST'])
def login_g():
    with sql.connect("alldata.db") as con:
        cur = con.cursor() 
        result = cur.execute("""SELECT email, password FROM users""").fetchall()
        emails = []
        passwords = []
        for i in result:
            emails.append(str(i[0]))
        for i in result:
            passwords.append(str(i[1]))
        if request.method == 'POST':
            print(emails, passwords, request.form['psw'], request.form['email'])
            if str(request.form['psw']) in passwords and str(request.form['email']) in emails:
                
                if str(request.form['psw']) == passwords[emails.index(str(request.form['email']))]:
                    global email
                    email = str(request.form['email'])
                    psw = str(request.form['psw'])                  
                    return redirect(url_for('home'))
                else:
                    return redirect(url_for('login_b'))
            else:
                return redirect(url_for('login_b'))
        return render_template('login_g.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    with sql.connect("alldata.db") as con:
        cur = con.cursor() 
        result = cur.execute("""SELECT email, password FROM users""").fetchall()
        emails = []
        passwords = []
        for i in result:
            emails.append(str(i[0]))
        for i in result:
            passwords.append(str(i[1]))
        if request.method == 'POST':
            print(emails, passwords, request.form['psw'], request.form['email'])
            if str(request.form['psw']) in passwords and str(request.form['email']) in emails:
                
                if str(request.form['psw']) == passwords[emails.index(str(request.form['email']))]:
                    global email
                    email = str(request.form['email'])
                    psw = str(request.form['psw'])                   
                    return redirect(url_for('home'))
                else:
                    return redirect(url_for('login_b'))
            else:
                return redirect(url_for('login_b'))
        return render_template('login.html')
    
@app.route('/reg_b', methods=['GET', 'POST'])
def reg_b():
    with sql.connect("alldata.db") as con:
        cur = con.cursor() 
        result = cur.execute("""SELECT email FROM users""").fetchall()
        emails = []
        for i in result:
            emails.append(i[0])
        if request.method == 'POST':
            if request.form['psw'] == request.form['psw_ch'] and request.form['email'] not in emails:
                cur.execute("""INSERT INTO users(email, password, location) VALUES ('%s', '%s', '%s')""" % (str(request.form['email']), str(request.form['psw']), str(request.form['location'])))
                return redirect(url_for('login_g'))
            else:
                return rendirect(url_for('reg_b'))
        else:
            return render_template('reg_b.html')

@app.route('/reg', methods=['GET', 'POST'])
def reg():
    with sql.connect("alldata.db") as con:
        cur = con.cursor() 
        result = cur.execute("""SELECT email FROM users""").fetchall()
        emails = []
        for i in result:
            emails.append(i[0])
        if request.method == 'POST':
            if request.form['psw'] == request.form['psw_ch'] and request.form['email'] not in emails:
                cur.execute("""INSERT INTO users(email, password, location) VALUES ('%s', '%s', '%s')""" % (str(request.form['email']), str(request.form['psw']), str(request.form['location'])))
                return redirect(url_for('login_g'))
            else:
                return redirect(url_for('reg_b'))
        else:
            return render_template('reg.html')



if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')